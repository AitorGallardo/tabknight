function E(G){try{let J=new URL(G);return J.hash="",J.host=J.host.toLowerCase(),J.href}catch{return G}}function W(G){let J=E(G),Y=2166136261;for(let Q=0;Q<J.length;Q+=1)Y^=J.charCodeAt(Q),Y=Math.imul(Y,16777619);return(Y>>>0).toString(16).padStart(8,"0")}var V=600;function L(G){for(let J of G){let Q=document.querySelector(J)?.content?.trim();if(Q)return Q}return}function A(G){if(!G)return;try{return new URL(G,document.location.href).href}catch{return}}function M(){let G=document.querySelector("link[rel~='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']");return A(G?.getAttribute("href")??void 0)}function k(){let G=document.querySelector("article")||document.querySelector("main")||document.querySelector("[role='main']")||document.body;if(!G)return;let Y=(G.innerText||"").replace(/\s+/g," ").trim();if(!Y)return;return Y.length>V?`${Y.slice(0,V).trimEnd()}…`:Y}function F(){let G=document.location.href;return{urlHash:W(G),url:G,title:(document.title||G).trim(),description:L(["meta[property='og:description']","meta[name='description']","meta[name='twitter:description']"]),ogImage:A(L(["meta[property='og:image']","meta[name='twitter:image']","meta[name='twitter:image:src']"])),siteName:L(["meta[property='og:site_name']"]),themeColor:L(["meta[name='theme-color']"]),excerpt:k(),favIconUrl:M(),scrollY:Math.round(window.scrollY)||0,capturedAt:Date.now()}}var I;function B(){try{let G=F();if(!G.url||G.url.startsWith("about:"))return;let J={type:"PREVIEW_CARD_CAPTURE",card:G};chrome.runtime.sendMessage(J).catch(()=>{})}catch{}}function P(G=800){window.clearTimeout(I),I=window.setTimeout(B,G)}function D(){if(window.scrollY>1)return;chrome.runtime.sendMessage({type:"PREVIEW_REQUEST_CAPTURE"}).catch(()=>{})}P(1200);window.setTimeout(D,1500);document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="hidden")B();else window.setTimeout(D,400)});var S;window.addEventListener("scroll",()=>{window.clearTimeout(S),S=window.setTimeout(()=>{B(),D()},1200)},{passive:!0});var R="tabknight-preview-host",H=140,y=200,C=4000,$=null,K,N=!1,x=!1,X=!1;function O(){return window.matchMedia("(prefers-reduced-motion: reduce)").matches}function j(){if(X=!0,!$||x)return;let G=$,J=G.shadowRoot?.querySelector("[data-role='backdrop']");window.clearTimeout(K);let Y=()=>{if(G.remove(),$===G)$=null;x=!1};if(!J||O()){Y();return}x=!0,J.classList.remove("tkp-visible");let Q=!1,Z=()=>{if(Q)return;Q=!0,J.removeEventListener("transitionend",z),Y()},z=(q)=>{if(q.target===J&&q.propertyName==="opacity")Z()};J.addEventListener("transitionend",z),window.setTimeout(Z,y)}function U(){if(N||X)return;window.clearTimeout(K),j(),chrome.runtime.sendMessage({type:"PREVIEW_FALLBACK_STANDALONE"}).catch(()=>{})}function T(){if($){j();return}let G=document.createElement("div");G.id=R;let J=G.attachShadow({mode:"open"});document.documentElement.appendChild(G),$=G,N=!1,X=!1;let Y=chrome.runtime.getURL("popup/index.html?view=preview&overlay=1");J.innerHTML=`
    <style>
      :host { all: initial; }
      .tkp-backdrop {
        position: fixed; inset: 0; z-index: 2147483647;
        display: flex; align-items: center; justify-content: center;
        background: rgba(6, 7, 10, 0.34);
        backdrop-filter: blur(7px) saturate(105%);
        -webkit-backdrop-filter: blur(7px) saturate(105%);
        opacity: 0;
        transition: opacity ${H}ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .tkp-backdrop.tkp-visible { opacity: 1; }
      .tkp-panel {
        position: relative;
        width: min(1040px, 92vw); height: min(640px, 86vh);
        border-radius: 18px; overflow: hidden;
        background: linear-gradient(180deg, rgba(28, 28, 30, 0.86), rgba(20, 20, 22, 0.84));
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 32px 90px rgba(0, 0, 0, 0.55);
        backdrop-filter: blur(30px);
        -webkit-backdrop-filter: blur(30px);
        transform: scale(0.98);
        transition: transform ${H}ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .tkp-backdrop.tkp-visible .tkp-panel { transform: scale(1); }
      .tkp-skeleton {
        position: absolute; inset: 0; padding: 28px;
        display: flex; flex-direction: column; gap: 12px;
        pointer-events: none;
        transition: opacity 160ms ease;
      }
      .tkp-skeleton.tkp-hidden { opacity: 0; }
      .tkp-skel-row {
        height: 14px; border-radius: 7px;
        background: linear-gradient(90deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.13), rgba(255, 255, 255, 0.05));
        background-size: 200% 100%;
        animation: tkp-shimmer 1.6s ease-in-out infinite;
      }
      .tkp-skel-row--a { width: 32%; }
      .tkp-skel-row--b { width: 68%; }
      .tkp-skel-row--c { width: 52%; }
      @keyframes tkp-shimmer {
        0% { background-position: 200% 0; }
        100% { background-position: -200% 0; }
      }
      .tkp-frame { width: 100%; height: 100%; border: 0; background: transparent; position: relative; }
      @media (prefers-reduced-motion: reduce) {
        .tkp-backdrop, .tkp-panel, .tkp-skeleton, .tkp-skel-row { transition: none !important; animation: none !important; }
      }
    </style>
    <div class="tkp-backdrop" data-role="backdrop">
      <div class="tkp-panel">
        <div class="tkp-skeleton" data-role="skeleton">
          <div class="tkp-skel-row tkp-skel-row--a"></div>
          <div class="tkp-skel-row tkp-skel-row--b"></div>
          <div class="tkp-skel-row tkp-skel-row--c"></div>
        </div>
        <iframe class="tkp-frame" src="${Y}" referrerpolicy="no-referrer"></iframe>
      </div>
    </div>
  `;let Q=J.querySelector("[data-role='backdrop']");Q?.addEventListener("mousedown",(z)=>{if(z.target===Q)j()});let Z=J.querySelector(".tkp-frame");if(Z?.addEventListener("load",()=>Z.contentWindow?.focus()),Z)Z.onerror=()=>U();if(Q)if(O())Q.classList.add("tkp-visible");else requestAnimationFrame(()=>requestAnimationFrame(()=>Q.classList.add("tkp-visible")));K=window.setTimeout(U,C)}window.addEventListener("message",(G)=>{let J=G.data;if(J?.source!=="tabknight-preview")return;if(J.type==="ready")N=!0,window.clearTimeout(K),$?.shadowRoot?.querySelector("[data-role='skeleton']")?.classList.add("tkp-hidden");if(J.type==="close")j()});document.addEventListener("keydown",(G)=>{if($&&G.key==="Escape")G.preventDefault(),G.stopPropagation(),j()},!0);function f(){return Array.from(document.querySelectorAll("video, audio"))}function _(G){let J=G.filter((Q)=>!Q.paused&&!Q.ended);if(J.length>0)return J.reduce((Q,Z)=>Z.duration>Q.duration?Z:Q);let Y=G.filter((Q)=>Number.isFinite(Q.duration));return Y.length>0?Y.reduce((Q,Z)=>Z.duration>Q.duration?Z:Q):G[0]}async function g(G){let J=f();if(J.length===0)return{ok:!1,mediaCount:0,error:"no-media"};if(G.action!=="toggle-play")return{ok:!1,mediaCount:J.length,error:"unsupported-action"};let Y=J.filter((Z)=>!Z.paused&&!Z.ended);if(Y.length>0)return Y.forEach((Z)=>Z.pause()),{ok:!0,playing:!1,mediaCount:J.length};let Q=_(J);try{return await Q.play(),{ok:!0,playing:!0,mediaCount:J.length}}catch{return{ok:!1,playing:!1,mediaCount:J.length,error:"autoplay-blocked"}}}function b(){let G=f();if(G.length===0)return{ok:!1,mediaCount:0,error:"no-media"};let J=_(G);return{ok:!0,playing:!J.paused&&!J.ended,currentTime:J.currentTime,duration:Number.isFinite(J.duration)?J.duration:void 0,mediaCount:G.length}}chrome.runtime.onMessage.addListener((G,J,Y)=>{if(G?.type==="PREVIEW_OVERLAY_TOGGLE")return T(),Y({ok:!0}),!0;if(G?.type==="MEDIA_CONTROL")return g(G).then(Y),!0;if(G?.type==="MEDIA_STATUS")return Y(b()),!1;return!1});
